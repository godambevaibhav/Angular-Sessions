For 32-bit machines/windows and Mongodb 3.2.x:
	-> install Hotfix KB2731284
	-> First time need to run command:
			mongod --storageEngine=mmapv1 --dbpath="path\to\db" --journal


Install:
https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows/


Add C:\Program Files\MongoDB\Server\4.0\bin  to system PATH

md "\data\db" "\data\log"

mongod --dbpath="D:\gauravsaini\mongodb"

	Verify: [initandlisten] waiting for connections on port 27017

Create new DB and collection	
use gauravdb

db.customers.insertOne( { name: "Company Inc", address: "Highway 37" } );


Get all records:
db.getCollection("customers").find({})


In program folder ( D:\gauravsaini\Day-10_node-express-mongo\setup_mongo-operations ): 
		npm init 
			--> to create the package.json file 
install mongodb package: 
		npm i mongodb



Missing DLL issue:
Download Visual C++ Redistributable from:
	https://www.microsoft.com/en-in/download/details.aspx?id=48145

After installation, try to rerun mongo.exe.



Running Node - mongo application:
		---> node 1-find_one.js
	Few changes in JS code:
		1> change 'connect' method in JS file 
					---> connect(url, { useNewUrlParser: true }...
		Avoid “current URL string parser is deprecated” warning by setting 
		useNewUrlParser to true
		
		2> Change your DB name and collection name in JS file
		
		
Restful:
---------------

npm i express body-parser cors

Make the changes #1 and #2 as above in running node section.

node restful_customers_service.js

Use Postman to send request to restful service.

