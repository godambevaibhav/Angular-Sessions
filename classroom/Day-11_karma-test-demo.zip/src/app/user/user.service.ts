export class UserService {
  user = {
    name: 'Max'
  };
}
