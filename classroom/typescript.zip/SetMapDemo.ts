/* let set = new Set();

set.add(1);
set.add(1);
set.add(1);
set.add(2);
set.add(4);
console.log(set);
console.log(set.size);

let set2 = new Set([1, 2, 4, 6, 7]);
console.log(set2); */

/* let str = 'aabbccddhhaabbccddsscccaaaabbbbb';
let strArr = str.split('');
//console.log(strArr);

let set3 = new Set(strArr);
console.log(set3); */

console.log('----------------MAP---------------------');
/* let map = new Map();
map.set('a', 1);
map.set('b', 2);
map.set('c', 3);
map.set('d', 4);
console.log(map);

console.log(map.get('c')); */

// Fix for issue : Argument of type '(string | number)[][]' is not assignable to parameter of 
// type 'Iterable<[{}, {}]>'.
/* type myTuple = [number, string];

// let array_2d = [[1, 'one'], [2, 'two']]; // gives above error
let array_2d:myTuple[] = [[1, 'one'], [2, 'two']];
let map2 = new Map(array_2d);
map2.set(3, 'three');
console.log(map2);

for (let [key, val] of map2.entries()) {
    console.log(`${key} points to ${val}`);
} */

//Problem-1 : Find the count of chars in the given string

/* let str = 'aabbccddhhaabbccddsscccaaaabbbbb';
let strArr = str.split('');

let map3 = new Map();
for (let charVal of strArr) {
    if (map3.get(charVal) === undefined) {
        map3.set(charVal, 1);
    } else {
        let count = map3.get(charVal);
        count++;
        map3.set(charVal, count);
    }
}
console.log(map3); */

//Problem-2 : Find the count of words in the given string

let str = 'My name is Harsha. My hometown is Kanpur. My profession is Doctor';
let wordArray = str.split(' ');

let map3 = new Map();
for (let word of wordArray) {
    if (map3.get(word) === undefined) {
        map3.set(word, 1);
    } else {
        let count = map3.get(word);
        count++;
        map3.set(word, count);
    }
}
console.log(map3);