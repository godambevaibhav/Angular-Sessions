
/* let array = [{name: 'John', id: 0}, {name: 'Alex', id: 0}, {name: 'Alice', id: 0}]

function outer(array) {

    //private data
    let count = 0; 

    function getValue() {
        for (let ele of array) {
            ele.id = count +1;
            count++;
        }
        return array;
    }

    return getValue;
}

let functionFac = outer(array);
console.log(functionFac());
console.log(functionFac()); */

var actionCelebs = [{ name: "Akshay", id: 0 }, { name: "John", id: 0 }, { name: "Jet Li", id: 0 }];

var actionCelebs2 = [{ name: "Akshay2", id: 0 }, { name: "John2", id: 0 }, { name: "Jet Li2", id: 0 }];

function celebrityIDCreator(theCelebrities) {
    var i;
    var uniqueID = 100;
    for (i = 0; i < theCelebrities.length; i++) {
        theCelebrities[i]["getId"] = (function (value_i) {
            console.log('iife' + value_i);
            return function () {
                return uniqueID + value_i;
            }
        })(i);

        /* theCelebrities[i]["getId"] = function () {
            console.log('calling getId');
            return uniqueID + i;
        }; */
    }
    return theCelebrities;
}
var createIdForActionCelebs = celebrityIDCreator(actionCelebs);
var akshay = createIdForActionCelebs[0];
var john = createIdForActionCelebs[1];
var jetLi = createIdForActionCelebs[2];
console.log(akshay.getId()); // 103
console.log(john.getId());
console.log(jetLi.getId());
