class Person {

    name: String;
    city: String;
    age: Number;

    /* constructor() {
        console.log('no arg constructor of Person');
    } */

    constructor(name: String, city: String, age: Number) {
        console.log('call to base constructor: Peson');
        this.name = name;
        this.city = city;
        this.age = age;
    }

    sayHello() {
        console.log(`Hello ${this.name} !! Welcome to ${this.city}`);
    }
}

let p = new Person('John', 'Australia', 30);
p.sayHello();
console.log('------------------------------------');
class Employee extends Person {

    role: String;

    constructor (name: String, city: String, age: Number, role: String) {
        console.log('call to Child constructor: Employee');
        super(name, city, age);
        this.role = role;
    }

    sayHello() {
        console.log(`Wolla !! ${this.name} !! Congrats on your promotion`);
    }
}

let empl = new Employee('Bob', 'Jersey', 41, 'Manager');
console.log(empl);
empl.sayHello();
