import {Calculator} from './Calculator'

class AdvCalculator extends Calculator {

    constructor(x: Number, y: Number) {
        super(x, y);
    }

    mod() {
        let result = this.x.valueOf() % this.y.valueOf();
        console.log(`MOD of ${this.x} and ${this.y} = ${result}`);
    }

    power() {
        let result = Math.pow(this.x.valueOf(), this.y.valueOf());
        console.log(`Power of ${this.x} and ${this.y} = ${result}`);
    }
}

let cal1 = new Calculator(20, 56);
cal1.add();
cal1.sub();
cal1.multiply();
cal1.divide();

let advCal = new AdvCalculator(7, 3);
advCal.mod();
advCal.power();