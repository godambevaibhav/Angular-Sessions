class Calculator {
    x: Number;
    y: Number;
    
    constructor(x: Number, y: Number) {
        this.x = x;
        this.y = y;
    }

    add() {
        let result = this.x.valueOf() + this.y.valueOf();
        console.log(`Sum of ${this.x} and ${this.y} = ${result}`);
    }
    
    sub() {
        let result = this.x.valueOf() - this.y.valueOf();
        console.log(`Subtract of ${this.x} and ${this.y} = ${result}`);
    }

    multiply() {
        let result = this.x.valueOf() * this.y.valueOf();
        console.log(`Multiplication of ${this.x} and ${this.y} = ${result}`);
    }

    divide() {
        let result = this.x.valueOf() / this.y.valueOf();
        console.log(`Division of ${this.x} and ${this.y} = ${result}`);
    }
}

/* let cal1 = new Calculator(20, 56);
cal1.add();
cal1.sub();
cal1.multiply();
cal1.divide(); */

export {Calculator};