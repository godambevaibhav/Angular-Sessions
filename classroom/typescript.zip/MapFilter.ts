let salaries = [100, 200, 201, 301, 400, 501];

let salRevised = salaries.map(
    (ele) => {
        return ele + (ele * 0.01)
    });

// console.log(salaries);

// console.log(salRevised);


// let salRevised2 = salaries.map(
//     (ele) => {
//         if (ele % 2 == 0) {
//             let revSal = ele + (ele * 0.1);
//             console.log(`${ele} is even, revised Sal is ${revSal}`);
//             return revSal;
//         } else {
//             return ele;
//         }
//     });
// console.log(salRevised2);

//array.filter().map().filter()

let oddSalary = salaries.filter(
    (ele) => {
        if (ele % 2 != 0) {
            return ele;
        }
    }
)
.map(ele => {
    let revSal = ele + (ele * 0.1);
    console.log(`${ele} is even, revised Sal is ${revSal}`);
    return revSal;
});

console.log(oddSalary);