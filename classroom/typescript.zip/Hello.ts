// function f(n: number) {
//     return n*2;
// }
// let array = [1, 2, 3, 5];

// function double(f: any, array: any) {
//     //for (let i = 0; i< array.length; i++) {
//     for (let ele of array) {
//         let doubleValue = f(array[i]);
//         console.log(doubleValue);
//     }
    
// }

// double (f, array);

/* let f = function(n: number) {
    return n*2;
}

let arrwFunc = (n: any) => {return n*2;}
console.log(arrwFunc(20));

let array = [1, 2, 3, 5];

function double(f: any, array: any) {
    //for (let i = 0; i< array.length; i++) {
    for (let ele of array) {
        let doubleValue = f(ele);
        console.log(doubleValue);
    }
}
//double(arrwFunc, array);

double((n) => {return n+5}, array);

setTimeout(()=>{console.log('Welcome! ');},3000) */

//Helper methods
/* let str = "Gaurav";
let repeated = str.repeat(2);
console.log(repeated);

let msg = "Hello! welcome to the class";
console.log(msg.startsWith('hello'));
console.log(msg.startsWith('Hello')); */

console.log(Number.isFinite(Math.pow(2, 54)));
console.log(Number.isFinite(Infinity));
console.log(Number.isSafeInteger(Math.pow(2, 53)));