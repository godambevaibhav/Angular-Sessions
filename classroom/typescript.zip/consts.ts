const Animals = ['Tom', 'Jerry', 'Donald', 'Pluto'];
const size = Animals.length;

const Planets = ['Mercury', 'Venus', 'Earth', 'Mars'];

let double = (elem) => elem *2;

let Person = { name: 'Gaurav', city: 'pune' };

export { Animals, double, Person };