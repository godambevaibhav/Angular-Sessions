/* function* letterMaker() {
  yield 'a';
  yield 'b';
  yield 'c';
}

console.log('starting letter maker');
var begin = letterMaker();
console.log(begin.next().value);
console.log(begin.next().value);
console.log(begin.next().value);
console.log(begin.next().value); */

function* evens() {
    var t = 0;

    while (true) {
        t += 5;
        let reset = yield t;
        if (reset === true) {
            t = 0;
        }
    }
   
}

var evensGen = evens();
console.log(evensGen.next().value);
console.log(evensGen.next().value);
console.log(evensGen.next(true).value);
console.log(evensGen.next().value);