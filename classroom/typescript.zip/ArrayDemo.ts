
let arr = [];
console.log(arr.length);

arr = [1, 2, 3, 4, 5, 6];
console.log(arr.length);

//console.log([1, 2] + [2, 3]);

arr[8] = 10;
console.log(arr[6], arr[7], arr[8]);
console.log(arr.length);
arr[8] = undefined;
console.log(arr.length);

for (let ele of arr) {
    console.log(ele);
}

arr.push([2, 3, 4]);
arr.push({name: 'gaurav', place:'Pune'});
arr.push(function() {});
arr.push(1 + '');
console.log(arr);
console.log('final length '+ arr.length);
console.log('pop element (removes from last) ' + arr.pop());
console.log('shift element (removes from begin) ' + arr.shift());


console.log(arr);
// start, end
console.log(arr.slice(4, 7)); // returns the portion of array
//start, count
console.log(arr.splice(4, 7, 30, 31, 32)); // removes the portion of array and returns it
console.log(arr);

// add elements to the beginning of array
arr.unshift(1, 2, 3);

console.log(arr);
