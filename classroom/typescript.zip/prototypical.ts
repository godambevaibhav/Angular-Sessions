function Person2 (name: String, place: String) {
    this.name = name;
    this.place = place;
}

let p1 = new Person2('Garry', 'London');
p1.age = 10;
console.log(p1);

Person2.prototype.age;
Person2.prototype.display = function() {
    console.log(`${this.name} stays in ${this.place} and his age is ${this.age}`);
}

p1.display();

let p2 = new Person2('John', 'USA');
p2.age = 10;
console.log(p2);
p2.display();

let func = () => {
    let a= b = 100;
}
console.log(b);
console.log(a);

