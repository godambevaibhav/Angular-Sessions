import { Directive, ElementRef, Renderer2, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appIconStyle]'
})
export class IconStyleDirective implements OnInit {

  @Input('appIconStyle')
  defaultColor: string = 'transparent';
  @Input()
  newColor: string = 'grey';

  constructor(private elementRef: ElementRef,
    private renderer: Renderer2) { }

    ngOnInit() {
      this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', this.defaultColor);
    }
    @HostListener('mouseenter')
    onMouseEnter(eventData: Event) {
      this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', this.newColor);
    }
    @HostListener('mouseleave')
    onMouseLeave(eventData: Event) {
      this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', this.defaultColor);
    }
}
