import { Component, 
  OnInit, 
  Output, 
  EventEmitter, 
  ViewChild, 
  ElementRef, 
  OnChanges,
  Input, 
  SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit, OnChanges {

  @Output()
  itemAddedEvent = new EventEmitter<{ name: string, price: string, desc: string }>();

  itemName: string;
  itemPrice: string;
  itemDesc: string;

  @ViewChild('Quantity') Quantity: ElementRef;
  
  @Input() inputProp: number;

  constructor() {
    console.log('constructor called');
   }

   //triggers when  inputProp is modified from Parent comp.
   ngOnChanges(changes: SimpleChanges) {
      console.log(changes);
   }
  ngOnInit() {
    console.log('onInit called');
  }

  onSubmit() {
    this.itemAddedEvent.emit({
      name: this.itemName,
      price: this.itemPrice,
      desc: this.itemDesc
    });

    this.reset();

    //Display value from reference selector of the DOM element
    /* console.log(this.Quantity);
    console.log(this.Quantity.nativeElement.value); */
    /* this.Quantity.nativeElement.value = 90909; */

  }

  reset() {
    this.itemName = '';
    this.itemPrice = '';
    this.itemDesc = '';
  }
}
