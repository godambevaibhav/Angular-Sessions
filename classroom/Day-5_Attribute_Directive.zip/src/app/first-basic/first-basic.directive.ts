import { OnInit, ElementRef, Directive, Renderer2 } from "@angular/core";

@Directive({
    selector: '[bkColor]'
})
export class FirstBasic implements OnInit {
    constructor(private elementRef: ElementRef,
        private renderer: Renderer2) {
    }

    ngOnInit() {
        this.elementRef.nativeElement.style.backgroundColor = 'yellow';
        //this.renderer.setStyle(this.elementRef.nativeElement, 'background-color', 'yellow');
    }
}