import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AddItemComponent } from './add-item/add-item.component';
import { ItemCardComponent } from './item-card/item-card.component';

//Directives
import { FirstBasic } from './first-basic/first-basic.directive';
import { IconStyleDirective } from './iconStyle/icon-style.directive';

@NgModule({
  declarations: [
    AppComponent,
    AddItemComponent,
    ItemCardComponent,
    FirstBasic,
    IconStyleDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
