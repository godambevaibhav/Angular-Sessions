import { Component, OnInit, Input} from '@angular/core';

import {LoggingService} from '../logging.service';

import {ItemsUpdateService} from '../itemsUpdate.service';

@Component({
  selector: 'app-item-card',
  templateUrl: './item-card.component.html',
  styleUrls: ['./item-card.component.css'],
  providers: [LoggingService]
})
export class ItemCardComponent implements OnInit {

  @Input()
  itemCard: { name: string, price: string, desc: string };

  @Input()
  cardId: number;

  constructor(private log: LoggingService, private itemService: ItemsUpdateService) { }

  ngOnInit() {
  }

  removeCard() {
    this.log.logMessageById("in Item card component... ", this.cardId);
    this.itemService.removeItem(this.cardId);
  }

}
