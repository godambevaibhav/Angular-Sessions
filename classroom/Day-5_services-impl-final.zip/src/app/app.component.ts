import { Component, OnInit } from '@angular/core';

import { ItemsUpdateService } from './itemsUpdate.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ItemsUpdateService]
})
export class AppComponent implements OnInit {
  title = 'app';

  //need tp be initialized
  items: { name: string, price: string, desc: string } [] = [];

  constructor(private itemService: ItemsUpdateService) {
  }

  ngOnInit() {
    this.items = this.itemService.getItems();
  }

}
