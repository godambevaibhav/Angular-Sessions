export class LoggingService {

    logMessageById(message: string, id: number) {
        console.log('service logger: ', message, id)
    }

    logMessage(message: string) {
        console.log('service logger: ', message)
    }
}