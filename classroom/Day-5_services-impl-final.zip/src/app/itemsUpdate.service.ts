export class ItemsUpdateService {

    items : { name: string, price: string, desc: string }[] = [];

    getItems() {
        this.items.push({name:'Mobiles', price: '10,000', desc: 'Mobile description'});
        this.items.push({name:'Wallets', price: '999', desc: 'Wallets description'});
        this.items.push({name:'Pen Drives', price: '1999', desc: 'Pen Drives description'});
        return this.items;
    }

    addItem(itemAdded :{ name: string, price: string, desc: string }) {
        this.items.push(itemAdded);
    }
    
    removeItem(cardId: number) {
        this.items.splice(cardId, 1);
    }
} 