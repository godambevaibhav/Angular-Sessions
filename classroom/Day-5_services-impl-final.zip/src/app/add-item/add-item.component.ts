import {
  Component,
  OnInit,
  Input
} from '@angular/core';

import { LoggingService } from '../logging.service'
import { ItemsUpdateService } from '../itemsUpdate.service'

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css'],
  providers: [LoggingService]
})
export class AddItemComponent implements OnInit {

  itemName: string;
  itemPrice: string;
  itemDesc: string;

  constructor(private log: LoggingService, private itemService: ItemsUpdateService) {
    log.logMessage('Add Item Comp: constructor called');
  }

  ngOnInit() {
    this.log.logMessage('Add Item Comp: onInit called');
  }

  onSubmit() {
    this.itemService.addItem({
      name: this.itemName,
      price: this.itemPrice,
      desc: this.itemDesc
    });

    this.reset();
    this.log.logMessageById('In Item Add comp: Adding item to list', -1)

  }

  reset() {
    this.itemName = '';
    this.itemPrice = '';
    this.itemDesc = '';
  }
}
